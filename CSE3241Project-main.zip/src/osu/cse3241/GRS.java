package osu.cse3241;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;
import osu.cse3241.options.*;
import osu.cse3241.utilities.Utilities;
import java.lang.ClassNotFoundException; 

public class GRS {	
	
	// private static final String DATABASE = "database_binary.db";
	private static final String DATABASE = "checkpointDB.db";
	
	public static Connection conn = null;
	
    /**
     * Connects to the database if it exists, creates it if it does not, and returns the connection object.
     * 
     * @param databaseFileName the database file name
     * @return a connection object to the designated database
     */
    public static Connection initializeDB(String databaseFileName) {
		String url = "jdbc:sqlite:" + databaseFileName;
		Connection conn = null;

		try {
			Class.forName("org.sqlite.JDBC");
			conn = DriverManager.getConnection(url);

			if (conn != null) {
				DatabaseMetaData meta = conn.getMetaData();
				System.out.println("The driver name is " + meta.getDriverName());
				System.out.println("The connection to the database was successful.");
			} else {
				System.out.println("Null Connection");
			}
		} catch (ClassNotFoundException e) {
			System.out.println("SQLite JDBC driver not found.");
			System.out.println(e.getMessage());
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			System.out.println("There was a problem connecting to the database.");
		}

		return conn;
	}
	
    private static final Set<Character> MENU_OPTIONS = new HashSet<>(Arrays.asList('1', '2', '3', '4', '5', 'x'));
	
	private static void mainMenu(Scanner cin) {
	
		char selection;
		do {
			System.out.print("~Rental Home Robot Database System for Local Communities~\n"
					+ "1. View all Customer/Robots\n"
					+ "2. Generate Reports\n"
					+ "3. Transactions\n"
					+ "4. EDIT MENU\n"
					+ "Input numerical selection (or 'x' to quit): ");
			String input = cin.nextLine();
			selection = !input.isEmpty() ? input.charAt(0) : ' ';
			
			while(!MENU_OPTIONS.contains(selection)) {
				System.out.print("Incorrect option specified! Try again: ");
				input = cin.nextLine();
				selection = !input.isEmpty() ? input.charAt(0) : ' ';
			}
		
			switch(selection) {
				case '1':
					ViewCustomerRobot.menu(cin);
					break;
				case '2':
					/**TODO */
					GenerateReports.menu(cin);
					break;
				case '3':
					TransactionMenu.menu(cin);
					break;
				case '4':
					EditMenu.menu(cin);
					break;
				default: 
					break;
			}
			Utilities.printDivider();
		} while(selection!='x');
	}
	
	public static void main(String[] args) {
		conn = initializeDB(DATABASE);
		
		Scanner cin = new Scanner(System.in);
		mainMenu(cin);
		
		cin.close();
		try {
			if (conn != null) {
				conn.close();
			}
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		}
		
		System.out.println("Bye");
	}

}
