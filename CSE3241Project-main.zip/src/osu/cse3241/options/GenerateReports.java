package osu.cse3241.options;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

import osu.cse3241.GRS;
import osu.cse3241.sql.SQL;
import osu.cse3241.utilities.Utilities;

public class GenerateReports {

    private static final Set<Character> MENU_OPTIONS =
            new HashSet<>(Arrays.asList('1', '2', '3', '4', '5', '6', 'x'));

    public static void menu(Scanner cin) {
        Utilities.printDivider();
        System.out.print("GENERATE REPORTS:\n"
                + "1. Renting checkouts\n"
                + "2. Popular robot\n"
                + "3. Popular manufacturer\n"
                + "4. Popular driverless car\n"
                + "5. Robots checked out\n"
                + "6. Robots by type before year\n"
                + "Input numerical selection (or 'x' to quit): ");

        String input = cin.nextLine();
        char selection = !input.isEmpty() ? input.charAt(0) : ' ';

        while (!MENU_OPTIONS.contains(selection)) {
            System.out.print("Incorrect option specified! Try again: ");
            input = cin.nextLine();
            selection = !input.isEmpty() ? input.charAt(0) : ' ';
        }

        switch (selection) {
            case '1':
                rentingCheckouts(cin);
                break;
            case '2':
                popularRobot();
                break;
            case '3':
                popularManufacturer();
                break;
            case '4':
                popularDriverlessCar();
                break;
            case '5':
                robotsCheckedOut();
                break;
            case '6':
                robotsByType(cin);
                break;
            default:
                break;
        }
    }

    private static void rentingCheckouts(Scanner cin) {
        System.out.print("Input Customer ID: ");
        String customerIdText = cin.nextLine();

        if (customerIdText.trim().isEmpty()) {
            System.out.println("Customer ID is required.");
            return;
        }

        int customerId = Integer.parseInt(customerIdText);

        String sql =
                "SELECT c.FirstName || ' ' || c.LastName AS CustomerName, " +
                "COUNT(r.RentalID) AS TotalRobotsRented " +
                "FROM Customer AS c " +
                "LEFT JOIN Rental AS r ON c.CustomerID = r.CustomerID " +
                "WHERE c.CustomerID = ? " +
                "GROUP BY c.CustomerID, c.FirstName, c.LastName " +
                "ORDER BY TotalRobotsRented DESC, CustomerName ASC;";

        SQL.ps_ReportCustomerCount(sql, customerId);
    }

    private static void popularRobot() {
        String sql =
                "SELECT rb.RobotID, " +
                "rb.Name, " +
                "rb.Model, " +
                "COUNT(r.RentalID) AS TimesRented, " +
                "COALESCE(SUM( " +
                "   CASE " +
                "       WHEN r.ReturnDate IS NOT NULL " +
                "           THEN julianday(r.ReturnDate) - julianday(r.CheckoutDate) " +
                "       ELSE julianday(r.DueDate) - julianday(r.CheckoutDate) " +
                "   END " +
                "), 0) AS TotalRentedDays " +
                "FROM Robot AS rb " +
                "LEFT JOIN Rental AS r ON rb.RobotID = r.RobotID " +
                "GROUP BY rb.RobotID, rb.Name, rb.Model " +
                "ORDER BY TotalRentedDays DESC, TimesRented DESC, rb.Name ASC " +
                "LIMIT 1;";

        SQL.sqlQuery(GRS.conn, sql);
    }

    private static void popularManufacturer() {
        String sql =
                "SELECT m.ManufacturerID, " +
                "m.Name, " +
                "COUNT(r.RentalID) AS TotalRentedRobots " +
                "FROM Manufacturer AS m " +
                "JOIN Robot AS rb ON m.ManufacturerID = rb.ManufacturerID " +
                "JOIN Rental AS r ON rb.RobotID = r.RobotID " +
                "GROUP BY m.ManufacturerID, m.Name " +
                "ORDER BY TotalRentedRobots DESC " +
                "LIMIT 1;";

        SQL.sqlQuery(GRS.conn, sql);
    }

    private static void popularDriverlessCar() {
        String sql =
                "SELECT dc.CarID, " +
                "dc.Model, " +
                "dc.LicensePlate, " +
                "COUNT(d.DispatchID) AS TotalRobotsDelivered, " +
                "COALESCE(SUM(c.FacilityDistance), 0) AS ApproxMilesDriven " +
                "FROM CAR AS dc " +
                "LEFT JOIN Dispatch AS d ON dc.CarID = d.CarID " +
                "LEFT JOIN Rental AS r ON d.RentalID = r.RentalID " +
                "LEFT JOIN Customer AS c ON r.CustomerID = c.CustomerID " +
                "GROUP BY dc.CarID, dc.Model, dc.LicensePlate " +
                "ORDER BY TotalRobotsDelivered DESC, ApproxMilesDriven DESC " +
                "LIMIT 1;";

        SQL.sqlQuery(GRS.conn, sql);
    }

    private static void robotsCheckedOut() {
        String sql =
                "SELECT c.CustomerID, " +
                "c.FirstName, " +
                "c.LastName, " +
                "COUNT(ren.RentalID) AS TotalRentals " +
                "FROM Customer c " +
                "JOIN Rental ren ON c.CustomerID = ren.CustomerID " +
                "GROUP BY c.CustomerID, c.FirstName, c.LastName " +
                "ORDER BY TotalRentals DESC " +
                "LIMIT 1;";

        SQL.sqlQuery(GRS.conn, sql);
    }

    private static void robotsByType(Scanner cin) {
        System.out.print("Input year: ");
        String yearText = cin.nextLine();

        if (yearText.trim().isEmpty()) {
            System.out.println("Year is required.");
            return;
        }

        int year = Integer.parseInt(yearText);

        String sql =
                "SELECT r.Name, " +
                "CASE " +
                "   WHEN cc.RobotID IS NOT NULL THEN 'ChildCareRobot' " +
                "   WHEN cl.RobotID IS NOT NULL THEN 'CleaningRobot' " +
                "   WHEN co.RobotID IS NOT NULL THEN 'CookingRobot' " +
                "   WHEN ec.RobotID IS NOT NULL THEN 'ElderlyCareRobot' " +
                "   WHEN ha.RobotID IS NOT NULL THEN 'HealthAssistantRobot' " +
                "   WHEN se.RobotID IS NOT NULL THEN 'SecurityRobot' " +
                "   ELSE 'Unknown' " +
                "END AS RobotType, " +
                "r.Model, " +
                "r.Year " +
                "FROM Robot r " +
                "LEFT JOIN ChildCareRobot cc ON r.RobotID = cc.RobotID " +
                "LEFT JOIN CleaningRobot cl ON r.RobotID = cl.RobotID " +
                "LEFT JOIN CookingRobot co ON r.RobotID = co.RobotID " +
                "LEFT JOIN ElderlyCareRobot ec ON r.RobotID = ec.RobotID " +
                "LEFT JOIN HealthAssistantRobot ha ON r.RobotID = ha.RobotID " +
                "LEFT JOIN SecurityRobot se ON r.RobotID = se.RobotID " +
                "WHERE r.Year < ? " +
                "AND (cc.RobotID IS NOT NULL OR cl.RobotID IS NOT NULL OR co.RobotID IS NOT NULL " +
                "     OR ec.RobotID IS NOT NULL OR ha.RobotID IS NOT NULL OR se.RobotID IS NOT NULL) " +
                "ORDER BY RobotType ASC, r.Name ASC;";

        SQL.ps_ReportYearFilter(sql, year);
    }
}
